package com.baekhwa.song.service;

public interface MailService {

	public long mailSend(String email);
	
	
}
