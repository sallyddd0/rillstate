package com.baekhwa.song.domain.entity;

public class ClubEntity {

	private long playerNo;
	
	private String player; //이름
	private String playerProfile; //선수 프로필
}
