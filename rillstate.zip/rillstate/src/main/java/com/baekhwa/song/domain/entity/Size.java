package com.baekhwa.song.domain.entity;

public enum Size {
	
	S,M,L,XL,XXL,XXXL
	
}
