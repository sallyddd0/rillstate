package com.baekhwa.song.domain.entity.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.baekhwa.song.domain.entity.MediaAnswerEntity;

public interface MediaAnswerRepository extends JpaRepository<MediaAnswerEntity, Integer>{

	
}
