package com.baekhwa.song.service.impl;

import org.springframework.stereotype.Service;
import com.baekhwa.song.domain.dto.media.MediaInsertDTO;
import com.baekhwa.song.service.MediaService;

@Service
public class MediaServiceProc implements MediaService{

	@Override
	public void save(MediaInsertDTO dto) {

		
	}

	

}
